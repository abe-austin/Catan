package client.communication;

import client.base.*;

/**
 * Game history controller interface
 */
public interface IGameHistoryController extends IController
{   
	
	// EMPTY
}
