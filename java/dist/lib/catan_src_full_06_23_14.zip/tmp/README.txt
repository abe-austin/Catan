There are example JSON files under the 'sample' folder
Run the server using "ant server".  Then navigate to localhost:8081/ in order to read the documentation.


